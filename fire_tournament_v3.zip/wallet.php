
<?php include 'common/config.php'; include 'common/header.php';
$uid=$_SESSION['u']['id'];

if(isset($_POST['dep'])){
$conn->query("INSERT INTO wallet_requests(user_id,amount,type,status) VALUES($uid,{$_POST['amt']},'deposit','pending')");
}
if(isset($_POST['with'])){
$conn->query("INSERT INTO wallet_requests(user_id,amount,type,status) VALUES($uid,{$_POST['amt']},'withdraw','pending')");
}
?>
<div class="card">
<form method="POST">
<input name="amt" placeholder="Amount">
<button name="dep">Deposit</button>
<button name="with">Withdraw</button>
</form>
</div>
<?php include 'common/bottom.php'; ?>
