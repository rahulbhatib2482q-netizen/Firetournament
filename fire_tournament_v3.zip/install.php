
<?php
$conn=new mysqli("127.0.0.1","root","root");
$conn->query("CREATE DATABASE IF NOT EXISTS fire_v3");
$conn->select_db("fire_v3");

$conn->query("CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(50),password VARCHAR(50),wallet FLOAT DEFAULT 0,wins INT DEFAULT 0)");
$conn->query("CREATE TABLE tournaments(id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(100),entry_fee FLOAT,prize FLOAT,status VARCHAR(20),room_id VARCHAR(50),room_pass VARCHAR(50))");
$conn->query("CREATE TABLE participants(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,tournament_id INT)");
$conn->query("CREATE TABLE notifications(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,message TEXT)");
$conn->query("CREATE TABLE wallet_requests(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,amount FLOAT,type VARCHAR(20),status VARCHAR(20))");

echo "Installed <a href='login.php'>Login</a>";
?>
