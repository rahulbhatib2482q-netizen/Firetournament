
<?php include 'common/config.php'; include 'common/header.php';
$uid=$_SESSION['u']['id'];
$r=$conn->query("SELECT * FROM notifications WHERE user_id=$uid");
while($n=$r->fetch_assoc()){
echo "<div class='card'>{$n['message']}</div>";
}
include 'common/bottom.php';
?>
