
<?php
$conn = new mysqli("127.0.0.1","root","root","fire_v3");
if($conn->connect_error){ die("DB Error"); }
session_start();
?>
