
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>FIRE TOURNAMENT</title>
<script>
document.addEventListener('contextmenu', e => e.preventDefault());
document.body.style.userSelect='none';
</script>
<style>
body{background:#0f172a;color:white;font-family:sans-serif;margin:0}
.card{background:#1e293b;padding:12px;border-radius:10px;margin:10px}
.btn{background:#22c55e;padding:10px;border-radius:8px;display:block;text-align:center}
</style>
</head>
<body>
