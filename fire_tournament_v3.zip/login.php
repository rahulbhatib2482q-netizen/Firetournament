
<?php include 'common/config.php';
if(isset($_POST['login'])){
$u=$_POST['u'];$p=$_POST['p'];
$r=$conn->query("SELECT * FROM users WHERE username='$u' AND password='$p'");
if($r->num_rows){$_SESSION['u']=$r->fetch_assoc();header("Location:index.php");}
}
if(isset($_POST['signup'])){
$conn->query("INSERT INTO users(username,password) VALUES('{$_POST['u']}','{$_POST['p']}')");
}
?>
<?php include 'common/header.php'; ?>
<div class="card">
<form method="POST">
<input name="u" placeholder="Username"><br>
<input name="p" placeholder="Password"><br>
<button name="login">Login</button>
<button name="signup">Signup</button>
</form>
</div>
<?php include 'common/bottom.php'; ?>
