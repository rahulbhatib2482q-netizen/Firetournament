
<?php include '../common/config.php';
$u=$conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
$t=$conn->query("SELECT COUNT(*) c FROM tournaments")->fetch_assoc()['c'];
?>
<h2>Admin Dashboard</h2>
Users: <?php echo $u; ?><br>
Tournaments: <?php echo $t; ?><br>
