
<?php include 'common/config.php'; include 'common/header.php';

if(isset($_POST['join'])){
$tid=$_POST['tid'];$uid=$_SESSION['u']['id'];
$conn->query("INSERT INTO participants(user_id,tournament_id) VALUES($uid,$tid)");
$conn->query("INSERT INTO notifications(user_id,message) VALUES($uid,'Joined tournament')");
}

$r=$conn->query("SELECT * FROM tournaments");
while($t=$r->fetch_assoc()){
echo "<div class='card'>";
echo "<h3>{$t['title']}</h3>";
echo "<p>Entry ₹{$t['entry_fee']}</p>";
echo "<form method='POST'>
<input type='hidden' name='tid' value='{$t['id']}'>
<button name='join' class='btn'>Join</button>
</form>";
echo "</div>";
}

include 'common/bottom.php';
?>
