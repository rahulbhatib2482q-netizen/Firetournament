
<?php include 'common/config.php'; include 'common/header.php';
$r=$conn->query("SELECT username,wins FROM users ORDER BY wins DESC");
while($u=$r->fetch_assoc()){
echo "<div class='card'>{$u['username']} - Wins: {$u['wins']}</div>";
}
include 'common/bottom.php';
?>
